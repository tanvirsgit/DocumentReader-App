<blockquote class="blockquote text-center">
  <p class="mb-0">Document Eye Tracker using Webgazer.js</p>
  <footer class="blockquote-footer">All rights reserved |<cite title="Source Title">&copy; 2018</cite></footer>
</blockquote>
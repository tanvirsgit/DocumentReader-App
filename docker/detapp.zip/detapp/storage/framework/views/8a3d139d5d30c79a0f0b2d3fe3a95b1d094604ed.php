<?php $__env->startSection('content'); ?>
    <div class="jumbotron text-center">
        <h1 class="display-3">Document Eye Tracker</h1>
        <p class="lead">This is a web based eye tracking application.</p>
        <hr class="my-4">
        <p>Visit the help page for more information</p>
        <p class="lead">
        <a class="btn btn-primary btn-lg" href="<?php echo e('help'); ?>" role="button">Learn more</a>
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
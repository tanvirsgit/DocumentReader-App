<?php $__env->startSection('content'); ?>
    <h1><?php echo e($document->title); ?></h1>
    <h5>Uploaded by: <?php echo e($document->initials); ?> | <?php echo e($document->user->name); ?></h5>
    <a href="/documents" class="btn btn-info" style="">Go Back</a>
    <hr>
    <small>Created at: <?php echo e($document->created_at); ?></small>
    <embed src="/storage/document_pdfs/<?php echo e($document->document_pdf); ?>" width="1440px" height="1080px"/>
    <br><br>
    <?php if(!Auth::guest()): ?>
        <?php if(Auth::user()->id == $document->user_id): ?>
        <a href="/documents/<?php echo e($document->id); ?>/edit" class="btn btn-info">Edit&nbsp;&nbsp;&nbsp;</a>
        <br><br>
        <?php echo Form::open(['action' => ['DocumentsController@destroy', $document->id], 'method' => 'POST', 'class' => 'pull-right']); ?>

            <?php echo e(Form::hidden('_method', 'DELETE')); ?>

            <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

        <?php echo Form::close(); ?>

        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
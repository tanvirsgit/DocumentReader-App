<?php $__env->startSection('content'); ?>
    <h1>Documents</h1>
    <center><a href="#" id="gazeBegin"><img src="<?php echo e(asset('img/eye.png')); ?>" alt=""></a></center>
    <?php if(count($documents) > 0): ?>
        <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="text-center">
                <a href="/documents/<?php echo e($document->id); ?>"><h4><?php echo e($document->title); ?></h4></a>
                <small>Uploaded by: <?php echo e($document->initials); ?> | <?php echo e($document->user->name); ?></small>
                <embed src="/storage/document_pdfs/<?php echo e($document->document_pdf); ?>" width="1440px" height="1080px"/>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($documents->links()); ?>

    <?php else: ?>
        <p>No documents found</p>
    <?php endif; ?>
    <center><a href="#" onclick="webgazer.end();"><img src="<?php echo e(asset('img/eye_cross.png')); ?>" alt=""></a></center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>